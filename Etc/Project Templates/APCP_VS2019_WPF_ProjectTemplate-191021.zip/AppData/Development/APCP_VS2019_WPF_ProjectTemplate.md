﻿# Visual Studio 2019 - A Pretty Cool Program - Project Template - WPF

> This is a changelog for the Visual Studio template this project uses.

## Build 191021
##### CHANGED
* ../Build/ -> ../build/
##### REMOVED
* /Du/

## Build 190918
##### CHANGED
* Updated Du to b190918

## Build 190916
##### CHANGED
* Updated Du to b190916
* All XAML files have the Exended Toolkit enabled
* All XAML code has been formatted

## Build 190912
##### CHANGED
* Updated Du to b190912
* Main(): DevMode.Testing(true) -> DevMode.Testing(false)
##### REMOVED
* ../Startup/Startup.cs
* ../Startup/

## Build 190910
##### INFORMATION
* Initial release

https://github.com/mgefvert/DotNetCommons/tree/master/src

https://github.com/xceedsoftware/wpftoolkit

https://github.com/kriasoft/Folder-Structure-Conventions

https://github.com/elsewhencode/project-guidelines

https://github.com/apache/httpd

https://github.com/microsoft/terminal

https://api.csswg.org/bikeshed/?force=1&url=https://raw.githubusercontent.com/vector-of-bool/pitchfork/develop/data/spec.bs

https://git-scm.com/docs/gitrepository-layout

https://github.com/python/cpython