﻿// ====================================================================================================================
//    FILENAME: Main.xaml.cs
//       BUILD: YYYYMMDD
//     PROJECT: ProjectName (https://github.com/GitHubAccount/ProjectName)
//     AUTHORS: email@your-email-address.com
//   COPYRIGHT: Copyright YYYY You
//     LICENSE: Project-license-type
// ====================================================================================================================

/* This is the main window/code of the project.
 */
namespace $safeprojectname$
{
    /// <summary>
    /// Interaction logic for Main.xaml
    /// </summary>
    public partial class Main
    {
        public Main()
        {
            InitializeComponent();
            DevMode.LaunchThenQuit(false);
            DevMode.Testing(false);
            Setup();
            Start();
        }

        /// <summary>
        /// Applies customizations to the Main() window when the application launches.
        /// </summary>
        private void Setup()
        {
            SetupControls();
            SetupWindow();
        }

        /// <summary>
        ///
        /// </summary>
        private void SetupControls()
        {
            /* Any control customizations go here.
             */
        }

        /// <summary>
        /// Applies customizations to the Main() window when the application launches.
        /// </summary>
        private void SetupWindow()
        {
            /* Any window customizations go here.
             */
        }

        /// <summary>
        /// Initializes a project.
        /// </summary>
        private void Start()
        {
            /* Initialization code goes here.
             */
        }
    }
}