﻿// ====================================================================================================================
//    FILENAME: DevMode.cs
//       BUILD: YYYYMMDD
//     PROJECT: ProjectName (https://github.com/GitHubAccount/ProjectName)
//     AUTHORS: email@your-email-address.com
//   COPYRIGHT: Copyright YYYY You
//     LICENSE: Project-license-type
// ====================================================================================================================

/* Development Mode code.
 */

using System;

namespace $safeprojectname$
{
    public class DevMode
    {
        /// <summary>
        /// Launch myAvatool, do something, then quit.
        /// </summary>
        /// <param name="enabled">[true, false]</param>
        public static void LaunchThenQuit(bool enabled)
        {
            /* There may be cases that you want to build external resources prior to actually running your project, and
             * that's what this method is for. DevMode.LaunchThenQuit() will do whatever is added here, then quit
             * the project before going any farther. For this to work, you'll need to have "DevMode.LaunchThenQuit()"
             * immediately after "InitializeComponent()" in the Main.cs constructor.
             *
             * This technically doesn't close gracefully.
             */
            if (enabled)
            {
                Environment.Exit(0);
            }
        }

        /// <summary>
        /// myAvatool testing procedures.
        /// </summary>
        /// <param name="enabled">[true, false]</param>
        public static void Testing(bool enabled)
        {
            /* Code here will execute each time your application is launched.
             */
            if (enabled)
            {
                // TESTING CODE GOES HERE.
            }
        }
    }
}