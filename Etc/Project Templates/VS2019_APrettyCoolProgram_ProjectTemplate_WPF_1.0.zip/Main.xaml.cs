﻿// ====================================================================================================================
//    FILENAME: Main.xaml.cs
//       BUILD: YYYYMMDD
//     PROJECT: ProjectName (https://github.com/GitHubAccount/ProjectName)
//     AUTHORS: email@your-email-address.com
//   COPYRIGHT: Copyright YYYY You
//     LICENSE: Project-license-type
// ====================================================================================================================

/* This is the main window/code of the project.
 */
using System.Windows;

namespace $safeprojectname$
{
    /// <summary>
    /// Interaction logic for Main.xaml
    /// </summary>
    public partial class Main : Window
    {
        public Main()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Applies customizations to the Main() window when the application launches.
        /// </summary>
        private void SetupWindow()
        {
            /* Any window customizations go here.
             */
        }


    }
}