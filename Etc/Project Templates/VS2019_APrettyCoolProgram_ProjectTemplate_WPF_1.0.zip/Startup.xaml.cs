﻿// ====================================================================================================================
//    FILENAME: Startup.xaml.cs
//       BUILD: YYYYMMDD
//     PROJECT: ProjectName (https://github.com/GitHubAccount/ProjectName)
//     AUTHORS: email@your-email-address.com
//   COPYRIGHT: Copyright YYYY You
//     LICENSE: Project-license-type
// ====================================================================================================================

/* This is the optional project startup.
 */
using System.Windows;

namespace $safeprojectname$
{
    /// <summary>
    /// Interaction logic for Startup.xaml
    /// </summary>
    public partial class Startup : Window
    {
        public Startup()
        {
            InitializeComponent();
            SetupWindow();
        }

        /// <summary>
        /// Applies customizations to the Startup window when it launches.
        /// </summary>
        private void SetupWindow()
        {
            /* Any window customizations go here.
             */
        }

        /// <summary>
        /// Initializes a project.
        /// </summary>
        private void Start()
        {
            /* Initialization code goes here.
             */
        }

        /// <summary>
        /// The ContinueButton is clicked.
        /// </summary>
        private void ContinueButtonClick()
        {
            Close();
        }

        /* Event handlers.
         */
        private void ContinueButton_Click(object sender, RoutedEventArgs e) => ContinueButtonClick();
    }
}