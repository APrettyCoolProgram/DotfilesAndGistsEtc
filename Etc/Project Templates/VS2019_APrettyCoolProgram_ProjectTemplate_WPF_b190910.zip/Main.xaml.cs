﻿// ====================================================================================================================
//    FILENAME: Main.xaml.cs
//       BUILD: YYYYMMDD
//     PROJECT: ProjectName (https://github.com/GitHubAccount/ProjectName)
//     AUTHORS: email@your-email-address.com
//   COPYRIGHT: Copyright YYYY You
//     LICENSE: Project-license-type
// ====================================================================================================================

/* This is the main window/code of the project.
 */
namespace $safeprojectname$
{
    /// <summary>
    /// Interaction logic for Main.xaml
    /// </summary>
    public partial class Main
    {
        public Main()
        {
            InitializeComponent();
            DevMode.LaunchThenQuit(false);
            DevMode.Testing(true);
        }

        /// <summary>
        /// Applies customizations to the Main() window when the application launches.
        /// </summary>
        private void SetupWindow()
        {
            /* Any window customizations go here.
             */
        }

        /// <summary>
        /// Initializes a project.
        /// </summary>
        private void Start()
        {
            /* Initialization code goes here.
             */
        }
    }
}