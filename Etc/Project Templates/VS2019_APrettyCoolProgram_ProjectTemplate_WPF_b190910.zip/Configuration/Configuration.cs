﻿// ====================================================================================================================
//    FILENAME: Configuration.cs
//       BUILD: YYYYMMDD
//     PROJECT: ProjectName (https://github.com/GitHubAccount/ProjectName)
//     AUTHORS: email@your-email-address.com
//   COPYRIGHT: Copyright YYYY You
//     LICENSE: Project-license-type
// ====================================================================================================================

/* This is the optional project configuration.
 */
namespace $safeprojectname$
{
    public class Configuration
    {
    }
}