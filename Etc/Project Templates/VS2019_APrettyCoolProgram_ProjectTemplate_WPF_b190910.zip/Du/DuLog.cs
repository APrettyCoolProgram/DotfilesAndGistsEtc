﻿// ====================================================================================================================
//    FILENAME: DuLog.cs
//       BUILD: 20190911
//     PROJECT: $safeprojectname$ (https://github.com/APrettyCoolProgram/$safeprojectname$)
//     AUTHORS: development@aprettycoolprogram.com
//   COPYRIGHT: Copyright 2019 A Pretty Cool Program
//     LICENSE: Apache License, Version 2.0
// ====================================================================================================================

using System;

namespace $safeprojectname$.Du
{
    public class DuLog
    {
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="toAppend"></param>
        public static void AppendData(string filePath, string toAppend)
        {
            var logEntry = Environment.NewLine
                         + "================================================================================" + Environment.NewLine
                         + DateTime.Now.ToString("yy-MM-dd-HH:mm:ss")                                         + Environment.NewLine
                         + "================================================================================" + Environment.NewLine
                         + toAppend
                         + Environment.NewLine;

            DuFile.AppendData(filePath, logEntry);
        }

    }
}