﻿// ====================================================================================================================
//    FILENAME: DuDownload.xaml.cs
//       BUILD: 20190911
//     PROJECT: Du (https://github.com/GitHubAccount/Du)
//     AUTHORS: development@aprettycoolprogram.com
//   COPYRIGHT: Copyright 2019 A Pretty Cool Program
//     LICENSE: Apache License, Version 2.0
// ====================================================================================================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;

namespace $safeprojectname$.Du
{
    /// <summary>
    /// Interaction logic for DuDownload.xaml
    /// </summary>
    public partial class DuDownload : Window
    {
        public DuDownload()
        {
            InitializeComponent();
        }

        /// <summary>Copy the contents of a source directory to a destination directory.</summary>
        /// <param name="source"></param>
        /// <param name="destination"></param>
        /// <param name="overwrite"></param>
        public static void Copy(string source, string destination, bool overwrite, string logFileName = "")
        {
            if ((!Exists(source)) && (logFileName != ""))
            {
                /*  This doesn't exit gracefully. There should be a message to the user that something went wrong.
                 */
                DuLog.AppendData(logFileName, "Source directory does not exist or could not be found: " + source);
                Environment.Exit(0);
            }

            Create(destination);

            var             sourceDirectory  = new DirectoryInfo(source);
            DirectoryInfo[] sourceDirSubDirs = sourceDirectory.GetDirectories();
            FileInfo[]      files            = sourceDirectory.GetFiles();

            foreach (var file in files)
            {
                var tempPath = Path.Combine(destination, file.Name);
                file.CopyTo(tempPath, overwrite);
            }

            foreach (var subdir in sourceDirSubDirs)
            {
                var tempPath = Path.Combine(destination, subdir.Name);
                Copy(subdir.FullName, tempPath, overwrite, logFileName);
            }
        }

        /// <summary></summary>
        /// <param name="target"></param>
        public static void Create(string target)
        {
            if (!Exists(target))
            {
                Directory.CreateDirectory(target);
            }
        }

        /// <summary>Delete all files in the target directory.</summary>
        /// <param name="target">Ex: "/target/directory/"</param>
        public static void DeleteFiles(string target)
        {
            var directoryFiles = Directory.GetFiles(target);

            foreach (var file in directoryFiles)
            {
                File.Delete(file);
            }
        }

        /// <summary>Delete all files in the target directory that are not in the toKeep list.</summary>
        /// <param name="target">Ex: "/target/directory/"</param>
        /// <param name="keep">A list of files to keep.</param>
        public static void DeleteFiles(string target, List<string> keep)
        {
            var directoryFiles = Directory.GetFiles(target);

            foreach (var file in directoryFiles.Where(file => !keep.Contains(Path.GetFileName(file))))
            {
                File.Delete(file);
            }
        }

        /// <summary>Get the file names in a directory.</summary>
        /// <param name="target">Ex: "/target/directory/"</param>
        /// <returns>The directory file names as a List<string>.</returns>
        public static List<string> GetFileNames(string target)
        {
            return Directory.GetFiles(target).ToList();
        }

        /// <summary></summary>
        /// <param name="target"></param>
        /// <returns></returns>
        public static bool Exists(string target)
        {
            var directoryInfo = new DirectoryInfo(target);

            return directoryInfo.Exists;
        }

        public static List<string> GetSubDirectoryNames(string target)
        {
            var subDirectoryNames = new List<string>();

            foreach (var subdirectory in Directory.GetDirectories(target))
            {
                var pathInfo = new DirectoryInfo(subdirectory);
                subDirectoryNames.Add(pathInfo.Name);
            }

            return subDirectoryNames;
        }

    }
}