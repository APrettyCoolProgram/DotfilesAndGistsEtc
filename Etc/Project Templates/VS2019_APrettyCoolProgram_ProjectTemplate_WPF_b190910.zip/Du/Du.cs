﻿// ====================================================================================================================
//    FILENAME: Du.cs
//       BUILD: 20190910
//     PROJECT: Du (https://github.com/APrettyCoolProgram/Du/)
//     AUTHORS: development@aprettycoolprogram.com
//   COPYRIGHT: Copyright 2019 A Pretty Cool Program
//     LICENSE: Apache License, Version 2.0
// ====================================================================================================================

/* Main Du class.
 */
namespace $safeprojectname$.Du
{
    public class Du
    {
        public static void DuTest()
        {
            DuExample.StandardCustomPopup();
            DuExample.FancyCustomPopup();
            DuExample.ErrorMessagePopup();
        }
    }
}