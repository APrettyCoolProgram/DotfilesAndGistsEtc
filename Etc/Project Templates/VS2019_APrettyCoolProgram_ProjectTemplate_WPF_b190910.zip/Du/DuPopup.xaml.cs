﻿// ====================================================================================================================
//    FILENAME: DuPopup.xaml.cs
//       BUILD: 20190911
//     PROJECT: Du (https://github.com/APrettyCoolProgram/Du)
//     AUTHORS: development@aprettycoolprogram.com
//   COPYRIGHT: Copyright 2019 A Pretty Cool Program
//     LICENSE: Apache License, Version 2.0
// ====================================================================================================================

/* DuPopup is a customizable popup window that you can use to display important information. Please see the
 * Du.TestStandardPopup() and Du.TestFancyPopup() methods for examples of how to use DuPopup.
 */
using System;
using System.Windows;
using System.Windows.Controls;

namespace $safeprojectname$.Du
{
    /// <summary>
    /// Interaction logic for DuMessagePopup.xaml
    /// </summary>
    public partial class DuPopup
    {
        /// <summary>
        /// Customizable message popup window.
        /// </summary>
        public DuPopup()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Displays a custom error message.
        /// </summary>
        /// <param name="msgTitle"></param>
        /// <param name="msgBody"></param>
        /// <returns></returns>
        public static void ErrorMessage(string msgTitle, string msgBody)
        {
            var errMsg = new DuPopup
            {
                PopupTitle               = "ERROR",
                MessageTitleText         = msgTitle,
                MessageBodyText          = msgBody,
                ActionButton01Visibility = Visibility.Hidden,
                ActionButton02Visibility = Visibility.Hidden,
                ActionButton03Content    = "OK",
                ActionButton03Visibility = Visibility.Visible,
            };
            errMsg.ShowDialog();
        }

        /// <summary>
        /// User clicks an ActionButton.
        /// </summary>
        /// <param name="sender">The ActionButton (i.e. "btnAction01").</param>
        private void ActionButtonClicked(object sender)
        {
           var btnAction = (Button)sender;

           switch (btnAction.Content.ToString().ToLower())
           {
               case "continue":
               case "ok":
                   Close();
                   break;

               case "exit":
                   Environment.Exit(0);
                   break;

               default:
                   break;
           }
        }

        /* Event handlers
         */
        private void BtnAction01_Click(object sender, RoutedEventArgs e) => ActionButtonClicked(sender);
        private void BtnAction02_Click(object sender, RoutedEventArgs e) => ActionButtonClicked(sender);
        private void BtnAction03_Click(object sender, RoutedEventArgs e) => ActionButtonClicked(sender);
    }
}