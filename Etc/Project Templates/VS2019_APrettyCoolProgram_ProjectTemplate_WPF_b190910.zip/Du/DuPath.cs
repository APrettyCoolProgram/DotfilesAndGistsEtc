﻿// ====================================================================================================================
//    FILENAME: DuPath.cs
//       BUILD: 20190910
//     PROJECT: Du (https://github.com/APrettyCoolProgram/Du)
//     AUTHORS: development@aprettycoolprogram.com
//   COPYRIGHT: Copyright 2019 A Pretty Cool Program
//     LICENSE: Apache License, Version 2.0
// ====================================================================================================================

/* DuPath utilities.
 */
namespace $safeprojectname$.Du
{
    public class DuPath
    {

    }
}