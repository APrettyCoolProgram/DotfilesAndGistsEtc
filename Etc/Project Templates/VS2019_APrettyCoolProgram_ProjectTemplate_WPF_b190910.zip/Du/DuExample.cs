﻿// ====================================================================================================================
//    FILENAME: DuExamples.cs
//       BUILD: 20190910
//     PROJECT: Du (https://github.com/APrettyCoolProgram/Du)
//     AUTHORS: development@aprettycoolprogram.com
//   COPYRIGHT: Copyright 2019 A Pretty Cool Program
//     LICENSE: Apache License, Version 2.0
// ====================================================================================================================

/* Examples for using various Du functionality.
 */

using System.Threading;
using System.Windows;
using System.Windows.Media;
using Newtonsoft.Json.Bson;

namespace $safeprojectname$.Du
{
    public class DuExample
    {
        #region DuPopup Examples
        /*
         * When you create a new DuPopup window, you need to provide the following information:
         *
         *  PopupTitle
         *  MessageTitleText
         *  MessageBodyText
         *  ActionButton01Visibility
         *  ActionButton01Content
         *  ActionButton02Visibility
         *  ActionButton03Visibility
         *
         * Every DuPopup window needs at least one ActionButton. I don't want to hide any of the ActionButtons when the
         * form is initialized, so you'll need to hide those that you don't use.
         */
        public static void StandardCustomPopup()
        {
            var messagePopupTest = new DuPopup
            {
                PopupTitle               = "Welcome",
                MessageTitleText         = "Welcome to The Application",
                MessageBodyText          = "We hope you enjoy using The Application. Have a nice day!",
                ActionButton01Visibility = Visibility.Visible,
                ActionButton01Content    = "OK",
                ActionButton02Visibility = Visibility.Hidden,
                ActionButton03Visibility = Visibility.Hidden,
            };
            messagePopupTest.ShowDialog();
        }

        /* There are a number of other properties you can set when you create a DuPopup window, but:
         *
         *  - The minimum height is 300, and the minimum width is 500. DuPopup windows smaller than this will not
         *    display correctly.
         */
        public static void FancyCustomPopup()
        {
            var messagePopupTest = new DuPopup
            {
                PopupHeight              = 800,
                PopupWidth               = 800,
                PopupTitle               = "Welcome",
                PopupOuterBackground     = new SolidColorBrush(Colors.CadetBlue),
                PopupInnerBackground     =  new SolidColorBrush(Colors.Azure),
                MessageTitleText         = "Welcome to The Application",
                MessageTitleForeground   = new SolidColorBrush(Colors.Chocolate),
                MessageBodyText          = "This is the Fancy Popup example.\n\nWe hope you enjoy using The Application. Have a nice day!",
                MessageBodyForeground    = new SolidColorBrush(Colors.Purple),
                ActionButton01Visibility = Visibility.Visible,
                ActionButton01Content    = "Exit",
                ActionButton01BackColor  = new SolidColorBrush(Colors.GhostWhite),
                ActionButton01ForeColor  = new SolidColorBrush(Colors.Red),
                ActionButton02Visibility = Visibility.Visible,
                ActionButton02Content    = "Continue",
                ActionButton02BackColor  = new SolidColorBrush(Colors.LightGreen),
                ActionButton02ForeColor  = new SolidColorBrush(Colors.Green),
                ActionButton03Visibility = Visibility.Hidden,
                ActionButton03Content    = "",
                ActionButton03BackColor  = new SolidColorBrush(Colors.Aqua),
                ActionButton03ForeColor  = new SolidColorBrush(Colors.Navy)
            };
            messagePopupTest.ShowDialog();
        }

        /// <summary>
        /// 
        /// </summary>
        public static void ErrorMessagePopup()
        {
            DuPopup.ErrorMessage("This application has encountered an error", "The source file cannot be found.");
        }
        #endregion DuPopup Examples
    }
}