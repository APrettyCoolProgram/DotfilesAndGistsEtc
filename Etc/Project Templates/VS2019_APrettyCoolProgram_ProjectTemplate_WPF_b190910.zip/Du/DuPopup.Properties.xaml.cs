﻿// ====================================================================================================================
//    FILENAME: DuMessagePopup.Properties.xaml.cs
//       BUILD: 20190910
//     PROJECT: Du (https://github.com/APrettyCoolProgram/Du/)
//     AUTHORS: development@aprettycoolprogram.com
//   COPYRIGHT: Copyright 2019 A Pretty Cool Program
//     LICENSE: Apache License, Version 2.0
// ====================================================================================================================

/* Properties for DuMessagePopup.xaml
 */
using System.Windows;
using System.Windows.Media;

namespace $safeprojectname$.Du
{
    public partial class DuPopup
    {
        public double PopupHeight
        {
            get => Height;
            set => Height = value;
        }

        public double PopupWidth
        {
            get => Width;
            set => Width = value;
        }

        public string PopupTitle
        {
            get => Title;
            set => Title = value;
        }

        public Brush PopupOuterBackground
        {
            get => brdrOuter.Background;
            set => brdrOuter.Background = value;
        }

        public Brush PopupInnerBackground
        {
            get => brdrInner.Background;
            set => brdrInner.Background = value;
        }

        public string MessageTitleText
        {
            get => tblkMessageTitle.Text;
            set => tblkMessageTitle.Text = value;
        }

        public Brush MessageTitleBackground
        {
            get => tblkMessageTitle.Background;
            set => tblkMessageTitle.Background = value;
        }

        public Brush MessageTitleForeground
        {
            get => tblkMessageTitle.Foreground;
            set => tblkMessageTitle.Foreground = value;
        }

        public string MessageBodyText
        {
            get => tblkMessageBody.Text;
            set => tblkMessageBody.Text = value;
        }

        public Brush MessageBodyBackground
        {
            get => tblkMessageBody.Background;
            set => tblkMessageBody.Background = value;
        }

        public Brush MessageBodyForeground
        {
            get => tblkMessageBody.Foreground;
            set => tblkMessageBody.Foreground = value;
        }

        public Visibility ActionButton01Visibility
        {
            get => btnAction01.Visibility;
            set => btnAction01.Visibility = value;
        }

        public string ActionButton01Content
        {
            get => (string)btnAction01.Content;
            set => btnAction01.Content = value;
        }

        public Brush ActionButton01BackColor
        {
            get => btnAction01.Background;
            set => btnAction01.Background = value;
        }

        public Brush  ActionButton01ForeColor
        {
            get => btnAction01.Foreground;
            set => btnAction01.Foreground = value;
        }

        public Visibility ActionButton02Visibility
        {
            get => btnAction02.Visibility;
            set => btnAction02.Visibility = value;
        }
        public string ActionButton02Content
        {
            get => (string)btnAction02.Content;
            set => btnAction02.Content = value;
        }

        public Brush ActionButton02BackColor
        {
            get => btnAction02.Background;
            set => btnAction02.Background = value;
        }

        public Brush ActionButton02ForeColor
        {
            get => btnAction02.Foreground;
            set => btnAction02.Foreground = value;
        }

        public Visibility ActionButton03Visibility
        {
            get => btnAction03.Visibility;
            set => btnAction03.Visibility = value;
        }

        public string ActionButton03Content
        {
            get => (string)btnAction03.Content;
            set => btnAction03.Content = value;
        }

        public Brush ActionButton03BackColor
        {
            get => btnAction03.Background;
            set => btnAction03.Background = value;
        }

        public Brush ActionButton03ForeColor
        {
            get => btnAction03.Foreground;
            set => btnAction03.Foreground = value;
        }
    }
}