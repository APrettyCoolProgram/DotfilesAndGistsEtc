﻿// <project-name>: https://github-account/repository-name
// <project-name>.App.xaml.cs
// b0000.0000
// (c) <YYYY> <name-of-copyright-owner>. Licensed under the Apache License 2.0
// This project uses the $safeprojectname$ (v2.2): https://github.com/aprettycoolprogram/some-templates

using System.Windows;

namespace $safeprojectname$
{
    public partial class App : Application
    {
    }
}
