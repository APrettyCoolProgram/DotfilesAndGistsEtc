# project-name Built With

* [Visual Studio Community 2019](https://visualstudio.microsoft.com/vs/) (including the extensions listed [here](https://github.com/APrettyCoolProgram/my-development-environment))
* [Visual Studio Code](https://code.visualstudio.com/?wt.mc_id=DX_841432) (including the extensions listed [here](https://github.com/APrettyCoolProgram/my-development-environment))

* [GitHub Desktop](https://desktop.github.com/)

* [.NET Core 5.0](https://dotnet.microsoft.com/download/dotnet-core)