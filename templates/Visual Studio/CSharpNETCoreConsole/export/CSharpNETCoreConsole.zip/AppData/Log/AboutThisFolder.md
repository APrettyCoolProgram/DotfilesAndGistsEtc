﻿# About /AppData/Log/
| DESCRIPTION                 | CREATED AT RUNTIME |
|-----------------------------|--------------------|
| Log files                   | Yes                |

### Additional notes
None.