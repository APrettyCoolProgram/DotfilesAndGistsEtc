﻿# About /AppData/Configuration/
| DESCRIPTION         | CREATED AT RUNTIME |
|------------------ --|--------------------|
| Configuration files | Yes                |

### Additional notes
None.