﻿# About /AppData/Document/
| DESCRIPTION                       | CREATED AT RUNTIME |
|-----------------------------------|--------------------|
| Documentation                     | Yes                |

### Additional notes
None.