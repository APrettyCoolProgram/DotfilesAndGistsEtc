﻿# About /AppData/Font/Embedded/
| DESCRIPTION                                      | CREATED AT RUNTIME |
|--------------------------------------------------|--------------------|
| Required fonts that are embedded in the assembly | Yes                |

### Additional notes
None.