﻿# .NET Core 3.0 xUnit Project Template

> This is a changelog for the Visual Studio template this project uses.

## Build 191122
##### INFORMATION
* Project name is now "CSharp_NETCore_xUnit_ProjectTemplate"
##### CHANGED
* Namespace changed to CSharp_NETCore_xUnit_ProjectTemplate
* Updated included dotfiles

## Build 191121
##### INFORMATION
* Initial release