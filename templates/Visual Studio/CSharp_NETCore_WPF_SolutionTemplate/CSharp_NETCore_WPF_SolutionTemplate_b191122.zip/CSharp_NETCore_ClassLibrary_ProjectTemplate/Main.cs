﻿// ===========================================================================================================  1:54 PM
//    FILENAME: Main.cs
//       BUILD: YYYYMMDD
//     PROJECT: ProjectName (https://github.com/GitHubAccount/ProjectName)
//     AUTHORS: your.email@here.com
//   COPYRIGHT: Copyright YYYY You
//     LICENSE: LicenseName
// ====================================================================================================================

/* This is the main logic of the library.
 */
namespace $safeprojectname$
{
    public class Main
    {
        public Main()
        {
            DevMode.LaunchApplicationThenQuit();
            DevMode.TestCode();
            StartLibrary();
        }

        /// <summary>Initializes a project.</summary>
        private static void StartLibrary()
        {
            /* Initialization code goes here.
             */
        }
    }
}