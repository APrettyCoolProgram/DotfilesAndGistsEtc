﻿// ===========================================================================================================  1:51 PM
//    FILENAME: Configuration.cs
//       BUILD: YYYYMMDD
//     PROJECT: ProjectName (https://github.com/GitHubAccount/ProjectName)
//     AUTHORS: your.email@here.com
//   COPYRIGHT: Copyright YYYY You
//     LICENSE: LicenseName
// ====================================================================================================================

/* Configuration logic.
 */
namespace $safeprojectname$
{
    public class Configuration
    {
        /// <summary>Default constructor.</summary>
        public Configuration()
        {
        }
    }
}