// ===========================================================================================================  10:02 AM
//    FILENAME: UnitTest.cs
//       BUILD: YYYYMMDD
//     PROJECT: ProjectName (https://github.com/GitHubAccount/ProjectName)
//     AUTHORS: your.email@here.com
//   COPYRIGHT: Copyright YYYY You
//     LICENSE: LicenseName
// ====================================================================================================================

using Xunit;

namespace $safeprojectname$
{
    public class UnitTest
    {
        [Fact]
        public void Test()
        {
        }
    }
}