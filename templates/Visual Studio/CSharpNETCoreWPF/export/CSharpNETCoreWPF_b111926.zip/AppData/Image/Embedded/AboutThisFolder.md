﻿# About /AppData/Font/Embedded/
| DESCRIPTION                                       | CREATED AT RUNTIME |
|---------------------------------------------------|--------------------|
| Required images that are embedded in the assembly | Yes                |

### Additional notes
None.