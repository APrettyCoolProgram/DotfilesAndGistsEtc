﻿# About /AppData/Development/
| DESCRIPTION                       | CREATED AT RUNTIME |
|-----------------------------------|--------------------|
| Devlopment data and documentation | Yes                |

### Additional notes
None.