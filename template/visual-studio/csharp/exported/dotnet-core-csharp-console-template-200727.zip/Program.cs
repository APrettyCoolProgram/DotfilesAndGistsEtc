﻿// Game Asset Studio (https://github.com/CalistadalaneGames/game-asset-studio)
// <file-name> (bMMDD.HHMM): <file-description>
// Authors:
//	calistadalane@aprettycoolprogram.com
//	development@aprettycoolprogram.com
// Additional documentation: /AppResource/Doc/Proj/

// $safeprojectname$-200727

using System;

namespace $safeprojectname$
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
