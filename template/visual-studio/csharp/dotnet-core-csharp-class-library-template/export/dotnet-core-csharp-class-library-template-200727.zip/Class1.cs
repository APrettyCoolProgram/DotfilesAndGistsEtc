﻿// <project-name>: https://github-account/repository-name
// <file-name> [<version/build>]: <file-description>
// Authors:
//  author01@email-address.com
//  author02@email-address.com
// Additional documentation: /ProjData/Doc/Proj/

// $safeprojectname$-200727

namespace $safeprojectname$
{
    public class Class1
    {
    }
}