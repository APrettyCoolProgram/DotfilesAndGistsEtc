﻿# About /AppData/Runtime/
| DESCRIPTION               | CREATED AT RUNTIME |
|---------------------------|--------------------|
| Files required at runtime | Yes                |

### Additional notes
None.