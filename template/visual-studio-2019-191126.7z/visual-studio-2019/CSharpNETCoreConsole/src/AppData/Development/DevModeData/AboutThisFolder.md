﻿# About /AppData/Development/DevModeData/
| DESCRIPTION                        | CREATED AT RUNTIME |
|------------------------------------|--------------------|
| Data for use with Development Mode | Yes                |

### Additional notes
You may have large amounts of data that you would normally download from a website, but in order to develop/test your
application without an internet connection, you could place the necessary files here and copy them to where they are
supposed to be at runtime.