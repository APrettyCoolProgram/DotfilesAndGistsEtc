﻿# About /AppData/Development/Dotfiles/
| DESCRIPTION                | CREATED AT RUNTIME |
|----------------------------|--------------------|
| IDE and extension settings | Yes                |

### Additional notes
None.