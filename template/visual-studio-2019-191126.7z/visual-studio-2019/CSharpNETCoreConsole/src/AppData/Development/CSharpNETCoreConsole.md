﻿# C# .NET Core 3.0 Console Application Project Template for Visual Studio 2019

> This is a changelog for the Visual Studio C# .NET Core 3.0 WPF Project Template

## Build 191126
##### INFORMATION
* Initial release