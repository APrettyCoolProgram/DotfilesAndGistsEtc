﻿# About /AppData/Temp/
| DESCRIPTION     | CREATED AT RUNTIME |
|-----------------|--------------------|
| Temporary files | Yes                |

### Additional notes
None.