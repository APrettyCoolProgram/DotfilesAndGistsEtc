﻿# About /AppData/Font/
| DESCRIPTION                       | CREATED AT RUNTIME |
|-----------------------------------|--------------------|
| Required fonts                    | Yes                |

### Additional notes
None.