﻿# About /AppData/Font/Local/
| DESCRIPTION                            | CREATED AT RUNTIME |
|----------------------------------------|--------------------|
| Required fonts that are stored locally | Yes                |

### Additional notes
None.