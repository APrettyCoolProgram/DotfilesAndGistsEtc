﻿# About /AppData/Image/Local/
| DESCRIPTION                             | CREATED AT RUNTIME |
|-----------------------------------------|--------------------|
| Required images that are stored locally | Yes                |

### Additional notes
None.