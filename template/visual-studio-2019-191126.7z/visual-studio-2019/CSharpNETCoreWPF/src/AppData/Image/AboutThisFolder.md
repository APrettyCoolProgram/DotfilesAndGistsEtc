﻿# About /AppData/Image/
| DESCRIPTION                        | CREATED AT RUNTIME |
|------------------------------------|--------------------|
| Required images                    | Yes                |

### Additional notes
None.