﻿# About /AppData/Import/

### Description
Data to be imported to your application should go here.

### Contents
Application specific, none by default.

### Created at runtime
Yes, always.

### Additional information
None.