﻿# About /AppData/Runtime/

### Description
Data needed at runtime.

### Contents
Application specific, none by default.

### Created at runtime
Yes, always.

### Additional information
None.