﻿# About /AppData/Development/DevModeData/

### Description
Development Mode data should be stored here.

### Contents
Application specific, none by default.

### Created at runtime
Yes, always.

### Additional information
If you have data that you retrieve from a remote location, you can store that data in DevModeData/ instead. When your
application starts, the data will be copied to where it should be at runtime.