# About appdata/dev/dotfile/visual-studio-code/
This directory contains setting and configuration files for [Microsoft Visual Studio Code](https://visualstudio.microsoft.com/)

**Created at runtime:** Yes, always.

| .**/**  |                                                                                                            |
| -------:|:---------------------------------------------------------------------------------------------------------- |
| various | Various configuration and setting files.                                                                   |
