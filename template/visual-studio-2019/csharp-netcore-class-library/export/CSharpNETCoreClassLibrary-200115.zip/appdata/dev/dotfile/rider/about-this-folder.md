# About appdata/dev/dotfile/rider/
This directory contains setting and configuration files for the [JetBrain Rider IDE](https://www.jetbrains.com/rider/)

**Created at runtime:** Yes, always.

| **/**   |                                                                                                            |
| -------:|:---------------------------------------------------------------------------------------------------------- |
| various | Various configuration and setting files.                                                                   |