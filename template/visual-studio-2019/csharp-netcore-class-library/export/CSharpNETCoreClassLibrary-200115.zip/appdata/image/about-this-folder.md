﻿# About appdata/image/
Application images.

**Created at runtime:** Yes, always.

| **/**         |                                                                                                     |
|:------------- |:--------------------------------------------------------------------------------------------------- |
| **embedded/** | Embedded images                                                                                     |     
| **local/**    | Local images                                                                                        |  