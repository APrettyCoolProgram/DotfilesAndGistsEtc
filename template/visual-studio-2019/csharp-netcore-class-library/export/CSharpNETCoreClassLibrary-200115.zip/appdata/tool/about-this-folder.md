﻿# About appdata/tool/
Application tool.

**Created at runtime:** Yes, always.

| **/**        |                                                                                                      |
|:------------ |:---------------------------------------------------------------------------------------------------- |
| various      | Application tools                                                                                    |     