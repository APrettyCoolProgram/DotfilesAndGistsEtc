﻿# About appdata/import/
Application imported data.

**Created at runtime:** Yes, always.

| **/**        |                                                                                                      |
|:------------ |:---------------------------------------------------------------------------------------------------- |
| various      | Imported data                                                                                        |    