﻿# About appdata/font/
Application fonts.

**Created at runtime:** Yes, always.

| **/**         |                                                                                                     |
|:------------- |:--------------------------------------------------------------------------------------------------- |
| **embedded/** | Embedded font                                                                                       |     
| **local/**    | Local font                                                                                          |  