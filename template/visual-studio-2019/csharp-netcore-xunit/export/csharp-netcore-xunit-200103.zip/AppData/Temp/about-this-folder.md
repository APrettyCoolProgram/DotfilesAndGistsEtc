﻿# About /AppData/Temp/

### Description
Temporary files should go here.

### Contents
Application specific, none by default.

### Created at runtime
Yes, always.

### Additional information
None.