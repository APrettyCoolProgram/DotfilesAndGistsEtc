﻿# About appdata/font/embedded/
Embedded fonts should go here.

**Created at runtime:** Yes, always.

| **/**        |                                                                                                      |
|:------------ |:---------------------------------------------------------------------------------------------------- |
| various      | Embedded fonts                                                                                       |