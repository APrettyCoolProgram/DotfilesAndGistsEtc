﻿# About appdata/font/local/
Local fonts should go here.

**Created at runtime:** Yes, always.

| **/**        |                                                                                                      |
|:------------ |:---------------------------------------------------------------------------------------------------- |
| various      | Local fonts                                                                                          |