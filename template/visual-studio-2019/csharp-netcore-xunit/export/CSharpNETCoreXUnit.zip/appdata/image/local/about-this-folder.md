﻿# About appdata/image/local/
Local images should go here.

**Created at runtime:** Yes, always.

| **/**        |                                                                                                      |
|:------------ |:---------------------------------------------------------------------------------------------------- |
| various      | Local images                                                                                         |