﻿# About appdata/dev/devmode/
If you have data that you retrieve from a remote location, you can store that data in DevModeData/ instead. When your
application starts, the data will be copied to where it should be at runtime.

**Created at runtime:** Yes, always.

| **/**   |                                                                                                           |
|:------- |:--------------------------------------------------------------------------------------------------------- |
| various | Configuration and setting data                                                                            |   
