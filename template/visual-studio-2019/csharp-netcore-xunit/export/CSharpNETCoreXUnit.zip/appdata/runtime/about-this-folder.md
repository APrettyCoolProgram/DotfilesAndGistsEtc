﻿# About appdata/runtime/
Data needed at runtime.

**Created at runtime:** Yes, always.

| **/**        |                                                                                                      |
|:------------ |:---------------------------------------------------------------------------------------------------- |
| various      | Imported data                                                                                        |    