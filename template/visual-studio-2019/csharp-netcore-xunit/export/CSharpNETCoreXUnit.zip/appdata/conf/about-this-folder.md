﻿# About appdata/conf/
Application configuration and setting files should be stored here.

**Created at runtime:** Yes, always.

| **/**        |                                                                                                      |
|:------------ |:---------------------------------------------------------------------------------------------------- |
| various      | Configuration and setting data                                                                       |     