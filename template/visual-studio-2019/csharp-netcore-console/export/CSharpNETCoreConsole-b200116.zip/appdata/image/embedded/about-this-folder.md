﻿# About appdata/image/embedded/
Embedded imagess should go here.

**Created at runtime:** Yes, always.

| **/**        |                                                                                                      |
|:------------ |:---------------------------------------------------------------------------------------------------- |
| various      | Embedded images                                                                                      |