﻿# About appdata/extension/
Application extensions.

**Created at runtime:** Yes, always.

| **/**   |                                                                                                           |
|:------- |:--------------------------------------------------------------------------------------------------------- |
| various | Application extensions                                                                                    |