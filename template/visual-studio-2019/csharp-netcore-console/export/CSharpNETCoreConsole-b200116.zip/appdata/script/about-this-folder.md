﻿# About appdata/script/
Application scripts.

**Created at runtime:** Yes, always.

| **/**        |                                                                                                      |
|:------------ |:---------------------------------------------------------------------------------------------------- |
| various      | Application scripts                                                                                  |     