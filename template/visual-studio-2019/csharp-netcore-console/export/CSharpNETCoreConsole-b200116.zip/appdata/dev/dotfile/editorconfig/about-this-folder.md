# About appdata/dev/dotfile/editorconfig/
This directory contains the .editorconfig file.

**Created at runtime:** Yes, always.

| /                      |                                                                                             |
|:---------------------- |:------------------------------------------------------------------------------------------- |
| `.editorconfig`        | Maintains consistent coding styles across editors [more info](https://editorconfig.org/) |