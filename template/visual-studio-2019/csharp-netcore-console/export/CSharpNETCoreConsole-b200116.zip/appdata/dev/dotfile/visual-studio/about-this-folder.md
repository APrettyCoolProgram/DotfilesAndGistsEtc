# About appdata/dev/dotfile/visual-studio/
This directory contains setting and configuration files for [Microsoft Visual Studio](https://visualstudio.microsoft.com/)

**Created at runtime:** Yes, always.

| **/**                                  |                                                                             |
| --------------------------------------:|:--------------------------------------------------------------------------- |
| `codealignmentsettings.xml`            |  |
| `license-header-manager.licenseheader` |  |
| `viasfora-settings.xml`                |  |
| `viasfora-theme.xml`                   |  |
| `visual-studio-2019.vssettings`        |  |
