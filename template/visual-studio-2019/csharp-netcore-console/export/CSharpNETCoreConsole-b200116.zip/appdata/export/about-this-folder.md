﻿# About appdata/export/
Application exported data.

**Created at runtime:** Yes, always.

| **/**        |                                                                                                      |
|:------------ |:---------------------------------------------------------------------------------------------------- |
| various      | Exported data                                                                                        |    