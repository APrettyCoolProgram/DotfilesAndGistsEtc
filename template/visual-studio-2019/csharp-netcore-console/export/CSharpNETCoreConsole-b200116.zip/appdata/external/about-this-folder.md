﻿# About appdata/external/
External codebases and dependencies.

**Created at runtime:** Yes, always.

| **/**   |                                                                                                           |
|:------- |:--------------------------------------------------------------------------------------------------------- |
| various | External codebases and dependencies                                                                       |   
