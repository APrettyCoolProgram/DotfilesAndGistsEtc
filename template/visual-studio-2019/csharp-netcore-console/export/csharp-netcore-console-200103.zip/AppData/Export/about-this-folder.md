﻿# About /AppData/Export/

### Description
Data exported from the application should go here.

### Contents
Application specific, none by default.

### Created at runtime
Yes, always.

### Additional information
None.