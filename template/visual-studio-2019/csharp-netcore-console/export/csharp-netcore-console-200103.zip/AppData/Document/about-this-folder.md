﻿# About /AppData/Document/

### Description
Application documentation and data should be stored here.

### Contents
Application specific, none by default.

### Created at runtime
Yes, always.

### Additional information
None.