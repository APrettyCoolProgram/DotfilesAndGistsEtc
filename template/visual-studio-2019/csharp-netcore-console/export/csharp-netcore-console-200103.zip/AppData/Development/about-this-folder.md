﻿# About /AppData/Development/

### Description
Development documentation and data should be stored here.

### Contents
* **changelog.md**
* **changelog-csharp-netcore-wpf**
* **development-notes**
* **known-issues.md**
* **license.md**
* **notices.md**
* **roadmap.md**
* **scratch-data.txt**

### Created at runtime
Yes, always

### Additional notes
None.