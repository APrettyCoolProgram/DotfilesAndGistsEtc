﻿# About /AppData/Font/Local

### Description
Embedded fonts should go here.

### Contents
Application specific, none by default.

### Created at runtime
Yes, always.

### Additional information
None.