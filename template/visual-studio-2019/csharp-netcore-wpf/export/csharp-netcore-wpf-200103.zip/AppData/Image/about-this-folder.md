﻿# About /AppData/Image

### Description
Images should go here.

### Contents
Application specific, none by default.

### Created at runtime
Yes, always.

### Additional information
None.