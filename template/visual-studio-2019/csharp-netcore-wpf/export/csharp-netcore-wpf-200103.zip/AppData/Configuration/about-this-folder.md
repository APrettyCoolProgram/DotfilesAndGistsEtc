﻿# About /AppData/Configuration/

### Description
Application configuration files should be stored here.

### Contents
Application specific, none by default.

### Created at runtime
Yes, always.

### Additional information
None.