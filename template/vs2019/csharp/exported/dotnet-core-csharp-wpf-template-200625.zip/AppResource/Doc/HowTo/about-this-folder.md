﻿### AppResource/Doc/HowTo/
> This file is a placeholder to ensure that *** AppResource/Doc/HowTo/*** is included in the GitHub repository, and is also
created (if it doesn't exist already) at runtime.

#### Purpose
Any how-to documents should be stored here.