﻿### AppResource/Dev/Doc/
> The `AppResource/Dev/Doc/` folder *is not* copied locally at runtime, and is only available with the sourcecode.

#### Purpose
Any development documentation should be stored here.

Examples of development documentation:
* Development notes
* Code snippits
* Design documents