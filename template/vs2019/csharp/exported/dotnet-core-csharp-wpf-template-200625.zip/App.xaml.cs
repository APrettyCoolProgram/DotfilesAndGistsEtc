﻿// <project-name>: https://github-account/repository-name
// <file-name> [<version/build>]: <file-description>
// Authors:
//  author01@email-address.com
//  author02@email-address.com
// Additional documentation: /AppResource/Doc/Proj/

// $safeprojectname$-200625


using System.Windows;

namespace $safeprojectname$
{
    public partial class App : Application
    {
    }
}
