﻿// <project-name>: https://github-account/repository-name
// <file-name> [<version/build>]: <file-description>
// Authors:
//  author01@email-address.com
//  author02@email-address.com
// Additional documentation: /AppResource/Doc/Proj/

using System.Windows;

namespace $safeprojectname$
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}