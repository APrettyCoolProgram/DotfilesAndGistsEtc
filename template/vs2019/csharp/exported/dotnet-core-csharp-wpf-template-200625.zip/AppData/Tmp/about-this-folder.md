﻿### AppData/Tmp/
> This file is a placeholder to ensure that ***AppData/Tmp/*** is included in the GitHub repository, and is also
created (if it doesn't exist already) at runtime.

#### Purpose
Temporary data is stored here.