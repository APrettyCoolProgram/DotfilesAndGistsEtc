﻿### AppData/Database/
> This file is a placeholder to ensure that ***AppData/Database/*** is included in the GitHub repository, and is also
created (if it doesn't exist already) at runtime.

#### Purpose
Application databases go here.