﻿// <project-name>: https://github-account/repository-name
// <project-name>.Class1.cs
// b0000.0000
// (c) <YYYY> <name-of-copyright-owner>. Licensed under the Apache License 2.0
// This project uses the dotnet-core-csharp-wpf-template-v2.2: https://github.com/aprettycoolprogram/some-templates

namespace $safeprojectname$
{
    public class Class1
    {
    }
}