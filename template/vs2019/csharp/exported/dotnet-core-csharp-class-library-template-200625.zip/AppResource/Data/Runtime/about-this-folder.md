﻿### AppResource/Data/Runtime/
> This file is a placeholder to ensure that ***AppResource/Data/Runtime/*** is included in the GitHub repository, and is also
created (if it doesn't exist already) when this application is launched.

#### Purpose
Any data needed at runtime should be stored here.