﻿### AppResource/Data/DevMode/
> This file is a placeholder to ensure that ***AppResource/Data/DevMode/*** is included in the GitHub repository, and is also
created (if it doesn't exist already) when this application is launched.

#### Purpose
Any data needed for Development Mode should be stored here.