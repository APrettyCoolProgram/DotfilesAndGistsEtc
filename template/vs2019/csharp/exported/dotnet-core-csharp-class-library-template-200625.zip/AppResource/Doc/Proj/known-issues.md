﻿> [project-name](https://github-account/project-name) v0.0<br>
> known-issues.md: Known issues.
> Additional documentation: /AppResource/Doc/Proj/

# KNOWN ISSUES

* InitialRunWindow
  * Clicking on the folder icon will continue to create new dialog windows.