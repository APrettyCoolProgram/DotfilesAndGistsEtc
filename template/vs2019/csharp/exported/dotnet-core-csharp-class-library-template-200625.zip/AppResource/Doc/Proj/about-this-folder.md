﻿### AppResource/Doc/Proj/
> This file is a placeholder to ensure that *** AppResource/Doc/Proj/*** is included in the GitHub repository, and is also
created (if it doesn't exist already) at runtime.

#### Purpose
Any project documentation should be stored here.