> [project-name](https://github-account/project-name) v0.0<br>
> acknowledgements.md: Acknowledgements.
> Additional documentation: /AppResource/Doc/Proj/

# ACKNOWLEDGEMENTS

Please see the [notices](url) document for third party acknowledgments.