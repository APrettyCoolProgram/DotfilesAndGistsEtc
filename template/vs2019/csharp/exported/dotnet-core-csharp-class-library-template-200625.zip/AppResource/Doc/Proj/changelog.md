> [project-name](https://github-account/project-name) v0.0<br>
> changelog.md: Project changelog.
> Additional documentation: /AppResource/Doc/Proj/

# CHANGELOG