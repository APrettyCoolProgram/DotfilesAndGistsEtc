> [project-name](https://github-account/project-name) v0.0<br>
> contrubuting.md: Contributing information.
> Additional documentation: /AppResource/Doc/Proj/

# CONTRIBUTING

When contributing to this repository, please first discuss the change you wish to make via issue, email, or any other method with the owners of this repository before making a change.

Please note we have a [Code of Conduct](code-of-conduct.md), please follow it in all your interactions with the project.

## CODE ORGANIZATION
Soon