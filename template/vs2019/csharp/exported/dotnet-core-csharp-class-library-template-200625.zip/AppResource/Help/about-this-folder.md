﻿### AppResource/Help/
> This file is a placeholder to ensure that ***AppResource/Asset/Help/*** is included in the GitHub repository, and is also
created (if it doesn't exist already) at runtime.

#### Purpose
All project help files belong here.