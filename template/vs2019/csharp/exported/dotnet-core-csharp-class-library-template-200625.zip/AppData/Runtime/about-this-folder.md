﻿### AppData/Runtime/
> This file is a placeholder to ensure that ***AppData/Config/*** is included in the GitHub repository, and is also
created (if it doesn't exist already) at runtime.

#### Purpose
Data needed at runtime is stored here.