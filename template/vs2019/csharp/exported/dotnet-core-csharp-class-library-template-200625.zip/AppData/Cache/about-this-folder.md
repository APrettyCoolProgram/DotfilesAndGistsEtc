﻿### AppData/Cache/
> This file is a placeholder to ensure that ***AppData/Cache/*** is included in the GitHub repository, and is also
created (if it doesn't exist already) at runtime.

#### Purpose
Data that is persistant across runtimes should be stored here.